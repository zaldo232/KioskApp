﻿using System.Windows.Controls;

namespace KioskApp.Views
{
    public partial class UserOrderConfirmView : UserControl
    {
        // 사용자 주문내역 확인 화면(결제 전 최종 확인)
        public UserOrderConfirmView()
        {
            InitializeComponent();
        }
    }
}
