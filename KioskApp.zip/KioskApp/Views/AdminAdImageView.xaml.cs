﻿using System.Windows.Controls;

namespace KioskApp.Views
{
    // 관리자 광고 이미지 관리 화면 코드비하인드
    public partial class AdminAdImageView : UserControl
    {
        public AdminAdImageView()
        {
            InitializeComponent(); // XAML UI 초기화
        }
    }
}
