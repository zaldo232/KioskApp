﻿using System.Windows.Controls;

namespace KioskApp.Views
{
    // 결제 완료 화면(사용자 주문 완료시 표시)
    public partial class PaymentCompleteView : UserControl
    {
        public PaymentCompleteView()
        {
            InitializeComponent();
        }
    }
}
