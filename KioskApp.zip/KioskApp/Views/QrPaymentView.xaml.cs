﻿using System.Windows.Controls;

namespace KioskApp.Views
{
    // QR 결제 화면(사용자에게 QR코드 보여주는 뷰)
    public partial class QrPaymentView : UserControl
    {
        public QrPaymentView()
        {
            InitializeComponent();
        }
    }
}
